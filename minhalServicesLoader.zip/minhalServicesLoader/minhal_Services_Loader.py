# -*- coding: utf-8 -*-
"""
/***************************************************************************


 minhalServicesLoader
                                 A QGIS plugin
  minhal Services Loader
                              -------------------
        begin                : 2018-11-01
        git sha              : $Format:%H$
        copyright            : (C) 2018 by Arie
        email                : arie@mapi.gov.il
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from qgis.PyQt.QtCore import QSettings, QTranslator, qVersion, QCoreApplication,Qt
from qgis.PyQt.QtGui import  QIcon, QCursor   
from qgis.PyQt.QtWidgets import QAction, QAbstractItemView, QMenu,QApplication
      
from qgis.core import QgsProject, QgsCoordinateReferenceSystem,QgsRasterLayer, \
                     QgsLayerTreeLayer,QgsLayerTreeGroup

# Initialize Qt resources from file resources.py
from .resources import   * #resources
# Import the code for the dialog
from .minhal_Services_Loader_dialog import minhalServicesLoaderDialog
import os.path
import subprocess


class minhalServicesLoader:
    """QGIS Plugin Implementation."""
    
    def addNewMenu (self, pluginDirName, pluginName):
        self.menu = self.iface.mainWindow().findChild(QMenu, '&מינהל התכנון' )
    #     self.menu = self.iface.mainWindow().findChild(QMenu, '&Personal Map' )
    
        if not self.menu :
            self.menu = QMenu( '&מינהל התכנון', self.iface.mainWindow().menuBar() )
            self.menu.setObjectName( '&מינהל התכנון' )
    #         self.menu = QMenu( '&Personal Map', self.iface.mainWindow().menuBar() )
    #         self.menu.setObjectName( '&Personal Map' )
    
            actions = self.iface.mainWindow().menuBar().actions()
            lastAction = actions[-1]
            self.iface.mainWindow().menuBar().insertMenu(lastAction, self.menu)        
            
            self.action = QAction(QIcon(":plugins/" + pluginDirName + "/mapi_logo.png"), pluginName, self.iface.mainWindow())  
#         self.action = QAction(QIcon(":plugins/" + pluginDirName + "/icon.png"), pluginName, self.iface.mainWindow())  
        self.action.triggered.connect(self.run)
        self.menu.addAction(self.action)
    
    def __init__(self, iface):
        """Constructor.

        :param iface: An interface instance that will be passed to this class
            which provides the hook by which you can manipulate the QGIS
            application at run time.
        :type iface: QgisInterface
        """
        # Save reference to the QGIS interface
        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'minhalServicesLoader_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)

            if qVersion() > '4.3.3':
                QCoreApplication.installTranslator(self.translator)


        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&minhal Services Loader')
        # TODO: We are going to let the user set this up in a future iteration
        self.toolbar = self.iface.addToolBar(u'minhalServicesLoader')
        self.toolbar.setObjectName(u'minhalServicesLoader')
        
        

    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        """Get the translation for a string using Qt translation API.

        We implement this ourselves since we do not inherit QObject.

        :param message: String for translation.
        :type message: str, QString

        :returns: Translated version of message.
        :rtype: QString
        """
        # noinspection PyTypeChecker,PyArgumentList,PyCallByClass
        return QCoreApplication.translate('minhalServicesLoader', message)


    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None):
        """Add a toolbar icon to the toolbar.

        :param icon_path: Path to the icon for this action. Can be a resource
            path (e.g. ':/plugins/foo/bar.png') or a normal file system path.
        :type icon_path: str

        :param text: Text that should be shown in menu items for this action.
        :type text: str

        :param callback: Function to be called when the action is triggered.
        :type callback: function

        :param enabled_flag: A flag indicating if the action should be enabled
            by default. Defaults to True.
        :type enabled_flag: bool

        :param add_to_menu: Flag indicating whether the action should also
            be added to the menu. Defaults to True.
        :type add_to_menu: bool

        :param add_to_toolbar: Flag indicating whether the action should also
            be added to the toolbar. Defaults to True.
        :type add_to_toolbar: bool

        :param status_tip: Optional text to show in a popup when mouse pointer
            hovers over the action.
        :type status_tip: str

        :param parent: Parent widget for the new action. Defaults None.
        :type parent: QWidget

        :param whats_this: Optional text to show in the status bar when the
            mouse pointer hovers over the action.

        :returns: The action that was created. Note that the action is also
            added to self.actions list.
        :rtype: QAction
        """

        # Create the dialog (after translation) and keep reference
        self.dlg = minhalServicesLoaderDialog()

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            self.toolbar.addAction(action)

        if add_to_menu:
            self.iface.addPluginToMenu(
                self.menu,
                action)

        self.actions.append(action)

        return action

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""
        
        icon_path = ':/plugins/minhalServicesLoader/mapi_logo.png'  #   icon_path = ':/plugins/minhalServicesLoader/icon.png'
        self.add_action(
            icon_path,
            text=self.tr(u'minhal Services Loader'),
            callback=self.run,
            parent=self.iface.mainWindow())
        
        self.addNewMenu( "minhalServicesLoader", "שכבות מינהל התכנון" )

    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(
                self.tr(u'&minhal Services Loader'),
                action)
            self.iface.removeToolBarIcon(action)
        # remove the toolbar
        del self.toolbar
        
        self.dlg.pushButtonHelp.clicked.disconnect(self.showManual)

    def defineVariables(self,services_list2):
        self.dlg.listService.clear()
        self.dlg.listService.setSelectionMode(QAbstractItemView.MultiSelection)            
        services_heb = []
        for service_tuple in services_list2 :                
            service_Heb_name = service_tuple[0]
            services_heb.append(service_Heb_name)          
        
        self.dlg.listService.addItems(services_heb)
            
        
    def drawService(self, services_list2):
        itemsInList = self.dlg.listService.count()
        root0 = QgsProject.instance().layerTreeRoot()
        root = root0
        delList = []

        plugin_path = os.path.dirname(os.path.realpath(__file__))
        layer0 = self.iface.addVectorLayer(  plugin_path+"//aa.shp", 'aa' , "ogr")
        myclone = layer0.clone()
        QgsProject.instance().addMapLayer(myclone,False)
        treeLay0 = QgsLayerTreeLayer (myclone)
        treeLay0.setExpanded(False)
        root.insertChildNode(0, treeLay0)    
        self.iface.setActiveLayer(myclone)                    
        QgsProject.instance().removeMapLayer(layer0.id())
        
        for i in range(itemsInList) :                
            itemm = self.dlg.listService.item(i)
            if itemm.isSelected() :                       
                root = root0      
                service_tuple = services_list2[i]
                len_tuple = len (service_tuple)  
                service_HEBname = service_tuple[0]   #0                
                service_name = service_tuple[1]   #0
#                 if service_name == "reka" :
#                     url_cur = "crs='EPSG:2039' filter='' url='https://ags.iplan.gov.il/arcgis/rest/services/PlanningPublic/" + service_name + "/MapServer/0'" + " table='' sql=''"
#                     layer = self.iface.addVectorLayer( url_cur, service_HEBname + ' WFS', "arcgisfeatureserver") 
#                     QgsProject.instance().layerTreeRoot().findLayer(layer.id()).setItemVisibilityChecked(False)
#                     url_cur = "crs='EPSG:2039' url='https://ags.iplan.gov.il/arcgis/rest/services/PlanningPublic/" + service_name + "/MapServer'  layer='0'"                                                
#                     layer = self.iface.addRasterLayer( url_cur, service_HEBname, "arcgismapserver")
                if service_name == "OpenStreetMap" :
                    urlWithParams = 'type=xyz&url=http://a.tile.openstreetmap.org/%7Bz%7D/%7Bx%7D/%7By%7D.png&zmax=19&zmin=0&crs=EPSG:2039'
                    rlayer = self.iface.addRasterLayer(urlWithParams, 'Open Street Map','wms')
                    if not rlayer.isValid():
                        print ("NO OSM service exist")
                    else :
                        QgsProject.instance().addMapLayer(rlayer)
                elif service_name == "Gushim"  :
                    # https://www.govmap.gov.il/?c=179288,664863&z=4&lay=SUB_GUSH_ALL
                    try:
                        urlWithParams = 'contextuaWMSLegend=0&crs=EPSG:2039&dpiMode=7&featureCount=10&format=image/png&layers=SUB_GUSH_ALL&styles=&url=https://open.govmap.gov.il/Proxy/proxy.ashx?http://govmap/geoserver/opendata/wms?'                   
                        rlayer2 = self.iface.addVectorLayer(urlWithParams, service_HEBname, 'wms')
                        if not rlayer2.isValid() :
                            print ("NO blocks service exist")
                        else: 
                            QgsProject.instance().addMapLayer(rlayer2) 
                    except:
                        pass
                              
                elif service_name == "Parcels"  :
                    urlWithParams = 'contextuaWMSLegend=0&crs=EPSG:2039&dpiMode=7&featureCount=10&format=image/png&layers=PARCEL_ALL&styles=&url=https://open.govmap.gov.il/Proxy/proxy.ashx?http://govmap/geoserver/opendata/wms?'
                    rlayer2 = QgsRasterLayer(urlWithParams, service_HEBname , 'wms')
                    if not rlayer2.isValid() :
                        print( "NO parcels service exist")
                    else: 
                        QgsProject.instance().addMapLayer(rlayer2)  
                elif service_name == "Atikot"  :
                    url_cur = "url='https://utility.arcgis.com/usrsvcs/servers/739dc828fe87439094c74437ffb4f7a4/rest/services/AtarMinhalTichnun/MapServer'  layer='0'"                    
                    layer = self.iface.addRasterLayer( url_cur, service_HEBname , "arcgismapserver")    
#                         url_cur = "crs='EPSG:2039' filter='' url='https://utility.arcgis.com/usrsvcs/servers/739dc828fe87439094c74437ffb4f7a4/rest/services/AtarMinhalTichnun/MapServer/0'" + " table='' sql=''"
#                         layer = self.iface.addVectorLayer( url_cur, service_HEBname, "arcgisfeatureserver")                     
                else:
                    root = root0   
                    if self.dlg.radWMS.isChecked() : 
                        nameGroup = service_HEBname + ' WMS'
                    else :
                        nameGroup = service_HEBname + ' WFS'
                    
                    groupRoot = root.addGroup(nameGroup)                    
                    for ii in range(2, len_tuple ) :                 #  for ii in range(len_tuple-1, 1, -1 ) :   #1                                    
                        if  isinstance(service_tuple[ii], tuple )  :
                            serviceHeb_Nam = service_tuple[ii][0] 
                            lay_num = service_tuple[ii][1]                            
                        else :
                            serviceHeb_Nam = service_tuple[ii] 
                            lay_num = str( ii - 2)
                        
                        if self.dlg.radWMS.isChecked() :                               
                            url_cur = "url='https://ags.iplan.gov.il/arcgis/rest/services/PlanningPublic/" + service_name + "/MapServer'  layer='" + lay_num + "'"                                                
                            layer = self.iface.addRasterLayer( url_cur, serviceHeb_Nam, "arcgismapserver")
                            if ii == len_tuple-1 :
                                canvas = self.iface.mapCanvas()
                                extent = layer.extent()
                                canvas.setExtent(extent)
                        elif self.dlg.radWFS.isChecked() :
                            try:
                                url_cur = "crs='EPSG:2039' filter='' url='https://ags.iplan.gov.il/arcgis/rest/services/PlanningPublic/" + service_name + "/MapServer/" + lay_num + "' table='' sql=''"
                                layer = self.iface.addVectorLayer( url_cur, serviceHeb_Nam, "arcgisfeatureserver") 
                                if ii == len_tuple-2 :
                                    canvas = self.iface.mapCanvas()
                                    extent = layer.extent()
                                    canvas.setExtent(extent)
                            except:
                                pass                        
                        try:
                            QgsProject.instance().layerTreeRoot().findLayer(layer.id()).setItemVisibilityChecked(False)
                            myclone = layer.clone()
                            QgsProject.instance().addMapLayer(myclone,False)
                            treeLay = QgsLayerTreeLayer (myclone)
                            treeLay.setExpanded(False)
                            treeLay.setItemVisibilityChecked(False )
                            groupRoot.addChildNode(treeLay)                        
                            delList.append(layer)
                        except:
                            pass    
                        

                    treeLay.setItemVisibilityChecked(True )  
        
        root = root0          
        root.removeChildNode( treeLay0)                                      
        for layer in delList:
            root.removeLayer(layer)  
             
    def showManual(self):
        scriptDir = os.path.dirname(os.path.realpath(__file__))
        subprocess.Popen(scriptDir + os.path.sep + 'readme.pdf',shell=True)    
    
    def run(self):
        # [('shem_servis_beTafrit','service_name',('layer_name','layer_number')) ]
        services_list2 = [ ('קומפילצית תמ"מ דרום' ,'compilation__tmm_darom',('גבול שינויי תממ','1'),('גבול מחוז','2'),('אזור לבירור','3')
                ,('נקודתי','4'),('קווים','5'),('מגבלות','6'),('יערות שמורות וסימונים נוספים','7'),('יעודי קרקע','8'),('קומפילצית תממ דרום','0')),
            ('קומפילצית תמ"מ מרכז' ,'compilation_tmm_merkaz',('גבול שינויי תמ"מים','1'),('גבול מחוז','2'),('אזורים לבירור','3'),('ישויות מחוץ לגבול המחוז','4')
                ,('סימבולים חוץ מחוז','5'),('קווים חוץ למחוז','6'),('מגבלות','7'),('מגבלות פוליגון','8'),('מגבלות קו','9'),('סימבולים','10'),('קווים','11')
                ,('לייבל ישובים' ,'13'),('יעודי קרקע','12'),('קומפילצית תממ מרכז','0')),
            ( 'קומפילצית תמ"מ חיפה' ,'compilation_tmm_haifa' ,('אזורים לבירור','1'),('גבול שינויי תמ"מים','2'),('גבול מחוז','3')
                ,('סימבולים','4'),('גבולות רשויות','5'),('קווים','6'),('מגבלות','7'),('יעודי קרקע','8'),('קומפילצית תממ חיפה','0')) ,
            ('קומפילצית תמ"מ צפון' ,'compilation_tmm_tzafonn',('מספרי כבישים','1'),('אזור לבירור','2'),('נקודה','3')
                ,('גבול שינויי תמ"מ','4'),('קו מחוץ לקומפילציה','5'),('קו','6'),('מגבלות','7'),('כנרת','8'),('יעוד קרקע','9'),('קומפילצית תממ צפון','0')) ,
            ( 'קומפילציית מערכת הולכת הגז הטבעי' ,'gaz_compilation','קומפילצית מערכת הולכת הגז הטבעי'
                ,'תחנות','תוואי הולכת גז טבעי','תמ"א 37/ 2 - צנרות דלק','תחום סקירה') ,
            ( 'גבולות - רצפים' ,'gvulot_retzef','מחוז','גבול שיפוט','ועד מקומי','מרחב תכנון','נפה'  ) ,
            ( 'מפות מפתח' ,'plan_index','מפות מפתח תמ"א','tma_all_kav_kahol_140216','tma_all_misgarot_140216','מפות מפתח תמ"מ',
                'tmm_all_kav_kahol_140216','tmm_all_misgarot_140216','מפות מפתח תת"ל','ttl_all_kav_kahol_140216') ,                       
            ( 'קומפילציית דרכים' ,'road_compilation',('מחלפים','1'),('תכניות מפורטות לדרכים','3') ,('דרכים','2'),('קומפילצית דרכים','0')),
            ( 'תמא/ 35 - תשריט הנחיות סביבתיות' ,'tama35_hanchayot_svivatiot','גבול ישראל','גבול תכנית1','גבול תכנית2','שמות ישובים','תחנות כוח'
                ,'שדה תעופה','קו צנרת גז טבעי','אגן היקוות כנרת','מחלפים','דרכים','תחום רעש מטוסים'
                ,'קו חשמל ראשי','שטחי שימור משאבי מים','רגישות נופית-סביבתית גבוהה','שטח בטחוני, שטחי אש ושטחים סגורים','אזורי החדרה ואיגום' ) ,
            ( 'תמא/ 1' ,'TAMA_1','תמא/ 1','רקע','מרקם עירוני - רקע','תשריט ראשי','סימון מיוחד - רכסים','דרכים'
                ,'מחלפים','דרכים','דרך לביטול','מסילות ברזל','מסילות_ברזל','חשמל','תחנות חשמל - לידיעה בלבד' , 'קווי חשמל ארציים מתכניות מאושרות - לידיעה בלבד','גז','מתקני גז','קו צינור הולכת גז'
                ,'מתחם ימי לרצועת תשתיות מתכנית מאושרת','מים','מתקן טיפול שפכים ארצי','אתר איגום והחדרה','אתר התפלה','מוצא ימי למי רכז','קו מים ארצי'
                , 'מוביל ארצי','קו קולחין ארצי','אתרי פסולת','אתרי פסולת','מוגנים','שמורות וגנים','יערות','נחלים','נחל ראשי','חופים','תיירות מוטת חוף','אזור מוטה שימושים נמליים, תשתיות, מער ופארק נחל','מעגן ונמל דייג'
                , 'פארק חוף עירוני','מכלול חוף','סיווג החוף','תשריט משני - תשתיות','מים','מתקן טיהור שפכים אזורי','קו קולחין אזורי','שטחים בעלי חשיבות להחדרה והעשרה של מי תהום','אזורי רגישות להחדרת מי נגר עילי'
                , 'חשמל','קו קצאא - לידיעה בלבד','קו תשן - לידיעה בלבד','תחנות כוח - לידיעה בלבד','תשריט משני - שטחים פתוחים','נחל משני','תחום יער','פשט הצפה','שטח הצפה','נספחים','פארק חוף עירוני'
                , 'אתר איגום והחדרה','אתר פסול"ת','אתרי התפלה','אתר התפלה עמק חפר','אתר התפלה שורק ופלמחים','אתר התפלה אשדוד','אתר התפלה אשקלון','רקע','תחום התכנית - רקע','שטח מיועד לפיתוח לפי תממ ושטח בנוי בפועל - רקע') ,            
            ( 'תמ"א 35/ 1 - תשריט מרקמים' ,'Tama_35_1',('מסדרון אקולוגי','1'),('ישובים מיוחדים','2') ,('שדה תעופה','3'),('מעבר גבול','4'),('מכלול שימור','5')
               ,('פארק מטרופוליני','6'),('נמל ים','7'),('מתקן ארצי','8') ,('מתקן בטחוני','9'),('רצועת נחל','10'),('תחנות רכבת','11'),('מסילות ברזל','12')
               ,('מחלפים','13'),('דרכים','14'),('רצועת נוף','15'),('גבול התכנית','16'),('גבול ישראל','17'),('גבול תכנית','18'),('גבול תכנית2','19')
               ,('מעטפת המכלול','20'),('מרקמים','21'),('רצף מרקמים','22'),('מרקמים לתצוגה בלבד','23'),('קו תוחם','24'),('מרקמים מילוי','25')
               ,('רצועת חוף','26'),('מכלולי נוף','27'),('שמורות וגנים','28'),('יער ויעור' ,'29'),('תמא/ 35/ 1','0')) ,            
            ( 'תמא/ 14/ ב' ,'tma_14_b','תמא/ 14/ ב','אתר לבחינת חציבה בתת הקרקע','תמא/ 14/ ב- אתרים' ) ,
            ('תמא/ 34/ ב/ 3' ,'tma_34_b_3' , 'גבול_תכנית','גבולות_מחוז_משרד_הפנים','גבול_רשויות_ניקוז','סיווג_נחלים_ארצי','עורק_ניקוז_במחוז_צפון','פשט_הצפה','נחל_לתכנון'),
            ('תמ"מ 1/ 30 - תשריט יעודי קרקע' ,'tmm_1_30','POINTS','KAVIM','GVUL','MIGBALOT','YK'),
            ('תמ"מ 2/ 9 - תשריט יעודי קרקע' ,'tmm_2_9' , 'שמות ישובים','גבול התכנית','גבול המחוז','מספרי דרכים','אזור תעסוקה מקומי' , 'אתר לאומי ואתר הנצחה','שדות תעופה','בתי סוהר','מחלפים','תחנות כוח','מסוף גבול','מסילת ברזל','דרכים','חשמל','רצועה עורפית - חופים','תחום הסביבה החופית','ייעודי קרקע' ) ,
            ('תמ"מ 3/ 21 - תשריט יעודי קרקע' ,'tmm_3_21','תממ 3/ 21 - תחנות','תממ 3/ 21 - מספרי כבישים','תממ 3/ 21 - גבול שטח אש','תממ 3/ 21 - רצועה למעבר קווי חשמל','תממ 3/ 21 - קווי חשמל','תממ 3/ 21 - (נתב"ג) מגבלות רעש','תממ 3/ 21 - (נתב"ג) מגבלת ציפורים','תממ 3/ 21 - מגבלת גובה','תממ-נתבג - גבול השקמא','תממ 3/ 21 - מחלפים','תממ 3/ 21 - כבישים','תממ 3/ 21 - דרך נופית','תממ 3/ 21 - מסילה','תממ 3/ 21 - שמות ישובים','תממ 3/ 21 - שמורה','תממ 3/ 21 - שדה תעופה','תממ 3/ 21 - מרכז תחבורה','תממ 3/ 21 - שמורה ימית','תממ 3/ 21 - קו חוף','תממ 3/ 21 - קו גז','תממ 3/ 21 - קו מים','תממ 3/ 21 - נחלים','תממ 3/ 21 - אתר טיהור שפכים','תממ 3/ 21 - אתר הנצחה ואתר לאומי','תממ 3/ 21 - שטח ערכי','תממ 3/ 21 - אתר אשפה','תממ 3/ 21 - גבול מוניציפלי','תממ 3/ 21 - גבול תכנית','תממ 3/ 21 - יעודי קרקע' ) ,
            ('תמ"מ 4/ 14 - תשריט יעודי קרקע' ,'tmm_4_14','ישויות מחוץ לגבול התכנית','סימבולים - מחוץ לגבול התכנית','קו_מים - מחוץ לגבול התכנית','מסילות_ברזל - מחוץ לגבול התכנית','דרכים - מחוץ לגבול התכנית','חשמל_מוצע - מחוץ לגבול התכנית','חשמל_מאושר - מחוץ לגבול התכנית','גבולות התוכנית','רצועת חוף','גבול התוכנית','סימבולים','קווי','מוביל מי ים','קו מים ארצי וקו מים ארצי שפד"ן','מסילות ברזל','שטח למעבר קווי ח"מל קיים מאושר','שטח למעבר קווי חשמל מוצע','דרכים','מגבלות','גבול נפה','גבול רשויות מקומיות','גבול שטחי אש ומתקנים בטחוניים','גבול שטח לתכנון תיירות','גבול שטח קרקעות שמורות בתחום זכיון ים המלח','גבול שטח קרקעות חכורות בתחום זכיון ים המלח','גבול שטח זכיון','תחום הרחקה ותחום בטיחות אתר כוח גרעיני','יעודי קרקע פוליגונלי' ),
            ('תממ 5/ 5- ייעודי קרקע' ,'tmm_5_5','תממ 5/ 5- ייעודי קרקע','גבול התכנית','מעבר רגלי','גבול תחום שיפוט','נקודות','LDN','לייבל דרכים','יעוד קרקע כסמל בית עלמין','נקודות תחבורה','קווים','נחל','מע"ר אז"רי','אתר תחזוקה ותפעול','הגבלות בניה ושימושי קרקע - נתב"ג','ייעודי קרקע') ,                        
            ('תמ"מ 5 - תשריט יעודי קרקע' ,'tmm_5','migbalotteufa_pnt','park_mutza_pnt','park_kaiam_pnt','tama21','sport_pnt','yk_pnt','maavar_ragli_l','migbalotteufa_l','nahal_l','prozdor_l','tamam_helki_l','tama23a_hasaa_l','zir_yarok_l','mirkam_mugan_pol','mitham_binuipituch_hadash_pol','tahatz_pol','yk_pol') ,
            ('תמ"מ 6 - תשריט יעודי קרקע' ,'tmm_6','gvul_mahoz','Gvul_municipali','YK_points','YK_kavim','YK_MIGBALOT','YK_pol') ,
            ('קומפילצית מסילות ברזל' ,'train_compilation','קומפילצית מסילות ברזל') ,
            ('ותמ"ל מתחמים מוכרזים' ,'vatmal_mitchamim_muchrazim' , 'ותמ"ל מתחמים מוכרזים') ,
            ('קוים כחולים-תכניות מקוונות' ,'Xplan_2039','קוים כחולים-תכניות מקוונות','יעודי קרקע' ,'מרחב תכנון'),
            ('מפת רקע- Open Street Map' ,'OpenStreetMap','מפת רקע- Open Street Map' ),
            ('גושים - המרכז למיפוי ישראל WMS' ,'Gushim','גושים' ),
            ('חלקות - המרכז למיפוי ישראל WMS','Parcels',  'חלקות'),
            ('אתרי עתיקות - רשות העתיקות WMS','Atikot','אתרי עתיקות') 
            ,('מפת רקע - מזרח התיכון','reka', 'מפת רקע - מזרח התיכון' )  ]
    
        
        self.defineVariables(services_list2)
        self.dlg.pushButtonHelp.clicked.connect(self.showManual)
        
        self.dlg.show()
        # Run the dialog event loop
        result = self.dlg.exec_()
        # See if OK was pressed
        if result:           
            QApplication.setOverrideCursor(QCursor(Qt.WaitCursor))
            self.drawService(services_list2)
            QApplication.setOverrideCursor(QCursor(Qt.ArrowCursor)) 
         