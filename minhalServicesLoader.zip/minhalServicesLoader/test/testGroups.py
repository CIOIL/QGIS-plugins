from qgis.core import QgsLayerTreeLayer, QgsLayerTreeNode,QgsProject 
from PyQt5.QtCore import Qt
url_cur = "url='https://ags.iplan.gov.il/arcgis/rest/services/PlanningPublic/Xplan_2039/MapServer' layer='0'"
layer = iface.addRasterLayer( url_cur, 'a1', "arcgismapserver")
QgsProject.instance().layerTreeRoot().findLayer(layer.id()).setItemVisibilityChecked(False)
#QgsProject.instance().addMapLayer(layer,False)
#treeLay0 = QgsLayerTreeLayer (layer)
#treeLay0.setItemVisibilityChecked (Qt.Unchecked )


#root = QgsProject.instance().layerTreeRoot()
#groupRoot = root.insertGroup(0,'aa' ) 


#
#myclone = layer.clone()
#QgsProject.instance().addMapLayer(myclone,False)
#treeLay = QgsLayerTreeLayer (myclone)
#groupRoot.insertChildNode(0,treeLay)    
#
#url_cur2 = "url='https://ags.iplan.gov.il/arcgis/rest/services/PlanningPublic/Xplan_2039/MapServer' layer='1'"
#layer2 = iface.addRasterLayer( url_cur2, 'a2', "arcgismapserver")
#myclone2 = layer2.clone()
#QgsProject.instance().addMapLayer(myclone2,False)
#treeLay2 = QgsLayerTreeLayer (myclone2)
#groupRoot.insertChildNode(0, treeLay2) 
#
#
#groupRoot2 = root.insertGroup(1,'bb' ) 
#
#url_cur = "url='https://ags.iplan.gov.il/arcgis/rest/services/PlanningPublic/Xplan_2039/MapServer' layer='0'"
#layer3 = iface.addRasterLayer( url_cur, 'b1', "arcgismapserver")
#myclone = layer3.clone()
#QgsProject.instance().addMapLayer(myclone,False)
#treeLay = QgsLayerTreeLayer (myclone)
#groupRoot2.insertChildNode(0,treeLay)    
#
#
#url_cur2 = "url='https://ags.iplan.gov.il/arcgis/rest/services/PlanningPublic/Xplan_2039/MapServer' layer='1'"
#layer4 = iface.addRasterLayer( url_cur2, 'b2', "arcgismapserver")
#myclone2 = layer4.clone()
#QgsProject.instance().addMapLayer(myclone2,False)
#treeLay2 = QgsLayerTreeLayer (myclone2)
#groupRoot2.insertChildNode(0,treeLay2)   
#
##קוים כחולים-תכניות מקוונות       
#
#root.removeLayer(layer)  
#root.removeLayer(layer2)  
#root.removeLayer(layer3)  
#root.removeLayer(layer4)  

