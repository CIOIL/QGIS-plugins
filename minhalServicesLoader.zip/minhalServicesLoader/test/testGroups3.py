from qgis.core import   QgsLayerTreeLayer , QgsProject 
root = QgsProject.instance().layerTreeRoot()
layers =[]
delList = []

groupRoot = root.addGroup('aa' ) 
url_cur = "url='https://ags.iplan.gov.il/arcgis/rest/services/PlanningPublic/Xplan_2039/MapServer' layer='0'"
layNam = 'a1'
layInfo = [url_cur, layNam, groupRoot]
layers.append(layInfo)
url_cur = "url='https://ags.iplan.gov.il/arcgis/rest/services/PlanningPublic/Xplan_2039/MapServer' layer='1'"
layNam = 'a2'
layInfo = [url_cur, layNam, groupRoot ]
layers.append(layInfo)

groupRoot = root.addGroup('bb' ) 
url_cur = "url='https://ags.iplan.gov.il/arcgis/rest/services/PlanningPublic/Xplan_2039/MapServer' layer='0'"
layNam = 'b1'
layInfo = [url_cur, layNam, groupRoot]
layers.append(layInfo)
url_cur = "url='https://ags.iplan.gov.il/arcgis/rest/services/PlanningPublic/Xplan_2039/MapServer' layer='1'"
layNam = 'b2'
layInfo = [url_cur, layNam, groupRoot ]
layers.append(layInfo)
for lay1 in layers:
    url_cur = lay1[0]
    layNam = lay1[1]
    groupRoot = lay1[2]
    layer = iface.addRasterLayer( url_cur, layNam, "arcgismapserver")
    myclone = layer.clone()
    QgsProject.instance().addMapLayer(myclone,False)
    treeLay = QgsLayerTreeLayer (myclone)
    groupRoot.insertChildNode(0,treeLay)  
    delList.append(layer)
   
for layer in delList:
   root.removeLayer(layer)   
 