from qgis.core import   QgsLayerTreeLayer , QgsProject 
root = QgsProject.instance().layerTreeRoot()
groupRoot = root.addGroup('aa' ) 


delList = []
url_cur = "url='https://ags.iplan.gov.il/arcgis/rest/services/PlanningPublic/Xplan_2039/MapServer' layer='0'"
layer = iface.addRasterLayer( url_cur, 'a1', "arcgismapserver")
delList.append(layer)
myclone = layer.clone()
QgsProject.instance().addMapLayer(myclone,False)
treeLay = QgsLayerTreeLayer (myclone)
groupRoot.addChildNode(treeLay)  


url_cur = "url='https://ags.iplan.gov.il/arcgis/rest/services/PlanningPublic/Xplan_2039/MapServer' layer='1'"
layer = iface.addRasterLayer( url_cur, 'a2', "arcgismapserver")
myclone = layer.clone()
QgsProject.instance().addMapLayer(myclone,False)
treeLay = QgsLayerTreeLayer (myclone)
groupRoot.addChildNode(treeLay) 
delList.append(layer)

#groupRoot2 = root.addGroup('bb' ) 
#url_cur = "url='https://ags.iplan.gov.il/arcgis/rest/services/PlanningPublic/Xplan_2039/MapServer' layer='0'"
#layer = iface.addRasterLayer( url_cur, 'b1', "arcgismapserver")
#myclone = layer.clone()
#QgsProject.instance().addMapLayer(myclone,False)
#treeLay = QgsLayerTreeLayer (myclone)
#groupRoot2.addChildNode(treeLay)    
#delList.append(layer)
#url_cur = "url='https://ags.iplan.gov.il/arcgis/rest/services/PlanningPublic/Xplan_2039/MapServer' layer='1'"
#layer = iface.addRasterLayer( url_cur, 'b2', "arcgismapserver")
#myclone = layer.clone()
#QgsProject.instance().addMapLayer(myclone,False)
#treeLay = QgsLayerTreeLayer (myclone)
#groupRoot2.addChildNode(treeLay)   
#delList.append(layer)

for layer in delList:
   root.removeLayer(layer)  
